package com.arscreenanchor.display

/** État partagé : orientation de la tête, point d'ancrage, mode et taille. */
object Anchor {
    @Volatile var yaw = 0f; @Volatile var pitch = 0f
    @Volatile var anchorYaw = 0f; @Volatile var anchorPitch = 0f
    @Volatile var locked = true
    @Volatile var sizePct = 50
    const val FOV = 46f          // champ de vision XREAL Air 2 (degrés)
    const val PITCH_SIGN = 1f    // mettre -1f si le haut/bas est inversé

    fun recenter() { anchorYaw = yaw; anchorPitch = pitch }

    private fun wrap(a: Float): Float { var x = a % 360f; if (x > 180f) x -= 360f; if (x < -180f) x += 360f; return x }

    /** Décalage de l'écran en degrés (0,0 en mode Suivi). */
    fun offsetYaw() = if (locked) wrap(anchorYaw - yaw) else 0f
    fun offsetPitch() = if (locked) (anchorPitch - pitch) * PITCH_SIGN else 0f
}
