package com.arscreenanchor.display

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Display
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var dot: View
    private lateinit var status: TextView
    private lateinit var go: Button
    private lateinit var tracker: Tracker
    private var pres: GlassesPresentation? = null
    private var running = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(c: Int, r: Int) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(c) }
    private fun btn(t: String, bg: Int, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE)
        background = shape(bg, 14); setOnClickListener { f() }
    }
    private fun external(): Display? =
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).displays.firstOrNull { it.displayId != Display.DEFAULT_DISPLAY }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tracker = Tracker(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0D1117.toInt()); setPadding(dp(20), dp(48), dp(20), dp(20))
        }
        fun add(v: View, top: Int = 14) = root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
        fun label(t: String) = TextView(this).apply { text = t; setTextColor(0xFF8B949E.toInt()); textSize = 14f }

        add(TextView(this).apply { text = "AR Screen Anchor"; setTextColor(Color.WHITE); textSize = 24f }, 0)
        dot = View(this); status = label("Lunettes non détectées")
        val st = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        st.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)).apply { rightMargin = dp(8) }); st.addView(status)
        add(st, 8)

        go = btn("Démarrer la copie", 0xFF4C9AFF.toInt()) { if (running) stop() else askCapture() }
        go.setTextColor(0xFF06101F.toInt()); add(go, 24)

        val row = LinearLayout(this)
        val lock = btn("Mode : Verrouillé", 0xFF21262D.toInt()) {}
        lock.setOnClickListener {
            Anchor.locked = !Anchor.locked; if (!Anchor.locked) Anchor.recenter()
            lock.text = "Mode : " + if (Anchor.locked) "Verrouillé" else "Suivi"
        }
        row.addView(btn("Recentrer", 0xFF21262D.toInt()) { Anchor.recenter() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        row.addView(lock, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        add(row)

        val size = label("Taille de l’écran : ${Anchor.sizePct} %")
        add(size, 24)
        add(SeekBar(this).apply {
            max = 80; progress = Anchor.sizePct - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { Anchor.sizePct = 20 + p; size.text = "Taille de l’écran : ${20 + p} %" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, 4)
        add(label("Suivi de tête : capteurs de la tablette (lecture des capteurs USB des lunettes pas encore implémentée)"), 24)
        setContentView(root)

        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(id: Int) = refresh()
            override fun onDisplayRemoved(id: Int) = refresh()
            override fun onDisplayChanged(id: Int) {}
        }, null)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val usb = Usb.find(this) != null; val ext = external() != null
        status.text = when { usb -> "Lunettes détectées (USB)"; ext -> "Écran externe détecté"; else -> "Lunettes non détectées" }
        dot.background = shape(if (usb || ext) 0xFF3FB950.toInt() else 0xFFF85149.toInt(), 6)
    }

    private fun askCapture() {
        if (external() == null) { Toast.makeText(this, "Branchez les lunettes (USB-C) d’abord", Toast.LENGTH_LONG).show(); return }
        startActivityForResult((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent(), 1)
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req != 1 || res != RESULT_OK || data == null) return
        CaptureService.onReady = { p -> runOnUiThread { begin(p) } }
        startForegroundService(Intent(this, CaptureService::class.java).putExtra("c", res).putExtra("d", data))
    }

    private fun begin(p: MediaProjection) {
        val d = external() ?: return
        val m = resources.displayMetrics
        Anchor.recenter(); tracker.start()
        pres = GlassesPresentation(this, d, p, m.widthPixels, m.heightPixels, m.densityDpi).also { it.show() }
        running = true; go.text = "Arrêter la copie"
    }

    private fun stop() {
        pres?.dismiss(); pres = null; tracker.stop()
        stopService(Intent(this, CaptureService::class.java))
        running = false; go.text = "Démarrer la copie"
    }
}
